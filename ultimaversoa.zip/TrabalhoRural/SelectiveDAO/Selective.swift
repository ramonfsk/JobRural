//
//  Selective.swift
//  TrabalhoRural
//
//  Created by Ramon Ferreira on 03/08/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import Foundation

class Selective {
    var type: String?
    var officeSelective: String?
    var email: String?
    var name: String?
    var lastName: String?
    var telephoe: String?
    
    init(json: [String: AnyObject]){
        self.type = json["type"] as? String ?? ""
        self.officeSelective = json["officeSelective"] as? String ?? ""
        self.email = json["email"] as? String ?? ""
        self.
    }
    
    init(){}
}
