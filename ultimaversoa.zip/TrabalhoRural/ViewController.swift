//
//  ViewController.swift
//  TrabalhoRural
//
//  Created by Ramon Ferreira on 02/08/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import UIKit

extension URLSession {
    func synchronousDataTask(with url: URL) -> (Data?, URLResponse?, Error?) {
        var data: Data?
        var response: URLResponse?
        var error: Error?
        
        let semaphore = DispatchSemaphore(value: 0)
        
        let dataTask = self.dataTask(with: url) {
            data = $0
            response = $1
            error = $2
            
            semaphore.signal()
        }
        dataTask.resume()
        
        _ = semaphore.wait(timeout: .distantFuture)
        
        return (data, response, error)
    }
}

class ViewController: UIViewController {

    @IBAction func goWorker(_ sender: Any) {
        performSegue(withIdentifier: "goWorker", sender: nil)
    }
    
    @IBAction func goProducer(_ sender: Any) {
        performSegue(withIdentifier: "goProducer", sender: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

