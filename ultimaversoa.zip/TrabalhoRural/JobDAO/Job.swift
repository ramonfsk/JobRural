//
//  Job.swift
//  TrabalhoRural
//
//  Created by Ramon Ferreira on 03/08/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import Foundation

class Job {
    var idJob: String?
    var type: String?
    var idWorkerExecute: String?
    var companyName: String?
    var office: String?
    var salary: Double?
    var period: Int?
    var nation: String?
    var state: String?
    var city: String?
    var description: String?
    var status: Int?
    var postDate: String?
    
    init(json: [String: AnyObject]){
        self.idJob = json["_id"] as? String ?? ""
        self.type = json["type"] as? String ?? ""
        self.idWorkerExecute = json["idWorkerExecute"] as? String ?? ""
        self.companyName = json["companyName"] as? String ?? ""
        self.office = json["office"] as? String ?? ""
        self.salary = json["salary"] as? Double ?? 0.0
        self.period = json["period"] as? Int ?? 0
        self.nation = json["nation"] as? String ?? ""
        self.state = json["state"] as? String ?? ""
        self.city = json["city"] as? String ?? ""
        self.description = json["description"] as? String ?? ""
        self.status = json["status"] as? Int ?? 0
        self.postDate = json["postDate"] as? String ?? ""
    }
    
    init(){}
}

class JobDAO {
    static func postJob(job: Job) {
        let url = URL(string: "https://jobrural.mybluemix.net/insert")!
        
        // Convert from Estacionamento to a valid JSON object (eg: Dictionary).
        let jobDict: [String: Any] = [
            "type": "job",
            "idWorkerExecute": job.idWorkerExecute,
            "companyName": job.companyName,
            "office": job.office,
            "salary": job.salary,
            "period": job.period,
            "nation": job.nation,
            "state": job.state,
            "city": job.city,
            "description": job.description,
            "status": 0
        ]
        
        // If object is valid JSON, sends data to server.
        if (JSONSerialization.isValidJSONObject(jobDict)) {
            print("Sending data to server...")
            let data = try! JSONSerialization.data(withJSONObject: jobDict)
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.httpBody = data
            let task = URLSession.shared.dataTask(with: urlRequest)
            task.resume()
        } else {
            print("JSON object is invalid!")
        }
    }
    
    static func getJob() -> [Job] {
        
        let url = URL(string: "https://jobrural.mybluemix.net/getAll")!
        
        let (data, _, error) = URLSession.shared.synchronousDataTask(with: url)
        
        if error != nil {
            return []
        }else{
            let json =  try! JSONSerialization.jsonObject(with: data!, options: []) as! [[String: AnyObject]]
            var jobs = [Job]()
            for obj in json {
                let job = Job(json: obj)
                jobs.append(job)
            }
            return jobs
        }
    }
}
