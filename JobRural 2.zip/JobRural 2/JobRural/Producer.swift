//
//  Producer.swift
//  JobRural
//
//  Created by student on 27/07/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import Foundation

extension URLSession {
    func synchronousDataTask(with url: URL) -> (Data?, URLResponse?, Error?) {
        var data: Data?
        var response: URLResponse?
        var error: Error?
        
        let semaphore = DispatchSemaphore(value: 0)
        
        let dataTask = self.dataTask(with: url) {
            data = $0
            response = $1
            error = $2
            
            semaphore.signal()
        }
        dataTask.resume()
        
        _ = semaphore.wait(timeout: .distantFuture)
        
        return (data, response, error)
    }
}

class Producer {
    var idUser: String?
    var type: String?
    var email: String?
    var typeUser: Int?
    var name: String?
    var lastName: String?
    var companyName: String?
    var gender: String?
    var telephone: Int?
    var nation: String?
    var state: String?
    var city: String?
    var rankGeneral: Int?
    
    init(json: [String: AnyObject]) {
        self.idUser = json["_id"] as? String ?? ""
        self.type = "profileProducer"
        self.email = json["email"] as? String ?? ""
        self.typeUser = 0
        self.name = json["name"] as? String ?? ""
        self.lastName = json["lastName"] as? String ?? ""
        self.companyName = json["companyName"] as? String ?? ""
        self.gender = json["gender"] as? String ?? ""
        self.telephone = json["telephone"] as? Int ?? 999999999999
        self.nation = json["nation"] as? String ?? ""
        self.state = json["state"] as? String ?? ""
        self.city = json["city"] as? String ?? ""
        self.rankGeneral = json["rankGeneral"] as? Int ?? 0
    }
}

class ProducerDAO {
    
    static func postProducer(producer: Producer) {
        let url = URL(string: "https://jobrural.mybluemix.net/insert")!
        
        // Convert from Estacionamento to a valid JSON object (eg: Dictionary).
        let producerDict: [String: Any] = [
            "type": producer.type,
            "_id": producer.idUser,
            "email": producer.email,
            "name": producer.name,
            "lastaName": producer.lastName,
            "companyName": producer.companyName,
            "gender": producer.gender,
            "telephone": producer.telephone,
            "nation": producer.nation,
            "state": producer.state,
            "city": producer.city,
            "rankGeneral": producer.rankGeneral
        ]
        
        // If object is valid JSON, sends data to server.
        if (JSONSerialization.isValidJSONObject(producerDict)) {
            print("Sending data to server...")
            let data = try! JSONSerialization.data(withJSONObject: producerDict)
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.httpBody = data
            let task = URLSession.shared.dataTask(with: urlRequest)
            task.resume()
        } else {
            print("JSON object is invalid!")
        }
    }
    
    static func getProducer() -> [Producer] {
        
        let url = URL(string: "https://jobrural.mybluemix.net/getAll")!
        
        let (data, _, error) = URLSession.shared.synchronousDataTask(with: url)
        
        if error != nil {
            return []
        }else{
            let json =  try! JSONSerialization.jsonObject(with: data!, options: []) as! [[String: AnyObject]]
            var producers = [Producer]()
            for obj in json {
                let producer = Producer(json: obj)
                producers.append(producer)
            }
            return producers
        }
    }
}
