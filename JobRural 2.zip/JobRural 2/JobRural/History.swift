//
//  History.swift
//  JobRural
//
//  Created by student on 27/07/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import Foundation

class History {
    var nameFarmer: String?
    var post: String?
    var time: Int?
    var rankPost: Int?
}
