//
//  Historic.swift
//  JobRural
//
//  Created by student on 30/07/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import Foundation

class Historic {
    
}
