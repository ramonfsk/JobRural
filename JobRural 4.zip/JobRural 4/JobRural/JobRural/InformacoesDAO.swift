//
//  InformacoesDAO.swift
//  JobRural
//
//  Created by student on 01/08/18.
//  Copyright © 2018 Reis do gado. All rights reserved.
//

import Foundation

extension URLSession {
    func synchronousDataTask(with url: URL) -> (Data?, URLResponse?, Error?) {
        var data: Data?
        var response: URLResponse?
        var error: Error?
        
        let semaphore = DispatchSemaphore(value: 0)
        
        let dataTask = self.dataTask(with: url) {
            data = $0
            response = $1
            error = $2
            
            semaphore.signal()
        }
        dataTask.resume()
        
        _ = semaphore.wait(timeout: .distantFuture)
        
        return (data, response, error)
    }
}

class Produtor {
    
    var nome: String = ""
    var sobrenome: String = ""
    var idade: String = ""
    var email: String = ""
    var senha: String = ""
    var nomeFazenda: String = ""
    var registroFazenda: String = ""
    var enderecoFazenda: String = ""
    
    
    init(json: [String: AnyObject]) {
        self.nome = json["nome"] as? String ?? ""
        self.sobrenome = json["sobrenome"] as? String ?? ""
        self.idade = json["idade"] as? String ?? ""
        self.email = json["email"] as? String ?? ""
        self.senha = json["senha"] as? String ?? ""
        self.nomeFazenda = json["nome da fazenda"] as? String ?? ""
        self.registroFazenda = json["registro da fazenda"] as? String ?? ""
        self.enderecoFazenda = json["endereço da fazenda"] as? String ?? ""
        
        
    }
    
    init() {
        
    }
}


class InformacoesDAO {
    
    static func postProdutor(produtor: Produtor) {
        let url = URL(string: "https://jobruralapp.mybluemix.net/inserirUsuario")!
        
        // Convert from Estacionamento to a valid JSON object (eg: Dictionary).
        let produtorDict: [String: Any] = [
            "nome": produtor.nome,
            "sobrenome": produtor.sobrenome,
            "idade": produtor.idade,
            "email": produtor.email,
            "senha": produtor.senha,
            "nome da fazenda": produtor.nomeFazenda,
            "registro da fazenda": produtor.registroFazenda,
            "endereco da fazenda": produtor.enderecoFazenda
        ]
        
        // If object is valid JSON, sends data to server.
        if (JSONSerialization.isValidJSONObject(produtorDict)) {
            print("Sending data to server...")
            let data = try! JSONSerialization.data(withJSONObject: produtorDict)
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.httpBody = data
            let task = URLSession.shared.dataTask(with: urlRequest)
            task.resume()
        } else {
            print("JSON object is invalid!")
        }
    }
    
    static func getProdutor() -> [Produtor] {
        
        let url = URL(string: "https://jobruralapp.mybluemix.net/listaBanco")!
        
        let (data, _, error) = URLSession.shared.synchronousDataTask(with: url)
        
        if error != nil {
            return []
        }else{
           let json =  try! JSONSerialization.jsonObject(with: data!, options: []) as! [[String: AnyObject]]
            var produtores = [Produtor]()
            for obj in json {
                let produtor = Produtor(json: obj)
                produtores.append(produtor)
            }
            return produtores
        }
        
        
    }
    
    
}
