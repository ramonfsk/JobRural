//
//  ViewController.swift
//  JobRural
//
//  Created by student on 27/07/18.
//  Copyright © 2018 Reis do gado. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
        
    
    @IBAction func BotaodeEntrar(_ sender: Any) {
        performSegue(withIdentifier: "goLogin", sender: nil)
    }
    @IBAction func BotaodeCadastrar(_ sender: Any) {
        performSegue(withIdentifier: "goPerfil", sender: nil)
        
    }
    @IBAction func BotaodeProdutor(_ sender: Any) {
        performSegue(withIdentifier: "goProdutor", sender: nil)
    }
    @IBAction func BotaodeTrabalhador(_ sender: Any) {
        performSegue(withIdentifier: "goTrabalhador", sender: nil)
    }

    @IBOutlet weak var NomeProdutor: UITextField!
    
    @IBOutlet weak var SobrenomeProdutor: UITextField!

    @IBOutlet weak var IdadeProdutor: UITextField!
  
    @IBOutlet weak var EmailProdutor: UITextField!
    
    @IBOutlet weak var SenhaProdutor: UITextField!
    
    @IBOutlet weak var NomeFazenda: UITextField!
    
    @IBOutlet weak var RegistroF: UITextField!
  
    @IBOutlet weak var Endereco: UITextField!
    
    

    @IBAction func ConcluirProdutor(_ sender: Any) {
        let produtor = Produtor()
        produtor.nome = self.NomeProdutor.text!
        produtor.sobrenome = self.SobrenomeProdutor.text!
        produtor.email = self.EmailProdutor.text!
        produtor.idade = self.IdadeProdutor.text!
        produtor.senha = self.SenhaProdutor.text!
        produtor.nomeFazenda = self.NomeFazenda.text!
        produtor.registroFazenda = self.RegistroF.text!
        produtor.enderecoFazenda = self.Endereco.text!
        
        InformacoesDAO.postProdutor(produtor: produtor)
        print(produtor)
    
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    //trabalhador
    
    @IBOutlet weak var nomeTrabalhador: UITextField!
    
    @IBOutlet weak var sobrenomeTrabalhador: UITextField!

    @IBOutlet weak var sexoTrabalhador: UISegmentedControl!
    
    @IBOutlet weak var idadeTrabalhador: UITextField!

    
    @IBOutlet weak var emailTrabalhador: UITextField!
    
    @IBOutlet weak var senhaTrabalhador: UITextField!
    
    @IBAction func concluirTrabalhador(_ sender: Any) {
        let trabalhador = Trabalhador()
        trabalhador.nome = self.nomeTrabalhador.text!
        trabalhador.sobrenome = self.sobrenomeTrabalhador.text!
        trabalhador.idade = self.idadeTrabalhador.text!
        trabalhador.email = self.emailTrabalhador.text!
        trabalhador.senha = senhaTrabalhador.text!
        
        TrabalhadorDAO.postTrabalhador(trabalhador: trabalhador)
        print(trabalhador)
        
    }
  
}

