//
//  TrabalhadorDAO.swift
//  JobRural
//
//  Created by student on 02/08/18.
//  Copyright © 2018 Reis do gado. All rights reserved.
//
import Foundation

extension URLSession {
    func synchronousDataTask(with url: URL) -> (Data?, URLResponse?, Error?) {
        var data: Data?
        var response: URLResponse?
        var error: Error?
        
        let semaphore = DispatchSemaphore(value: 0)
        
        let dataTask = self.dataTask(with: url) {
            data = $0
            response = $1
            error = $2
            
            semaphore.signal()
        }
        dataTask.resume()
        
        _ = semaphore.wait(timeout: .distantFuture)
        
        return (data, response, error)
    }
}

class Trabalhador {
    
    var nome: String = ""
    var sobrenome: String = ""
    var idade: String = ""
    var email: String = ""
    var senha: String = ""
    
    //var carro: [Carro]
    
    init(json: [String: AnyObject]) {
        self.nome = json["nome"] as? String ?? ""
        self.sobrenome = json["sobrenome"] as? String ?? ""
        self.idade = json["idade"] as? String ?? ""
        self.email = json["email"] as? String ?? ""
        self.senha = json["senha"] as? String ?? ""
        

    }
    
    init() {
        
    }
}


class TrabalhadorDAO {
    
    static func postTrabalhador(trabalhador: Trabalhador) {
        let url = URL(string: "https://jobruralapp.mybluemix.net/inserirUsuario")!
        
        // Convert from Estacionamento to a valid JSON object (eg: Dictionary).
        let trabalhadorDict: [String: Any] = [
            "nome": trabalhador.nome,
            "sobrenome": trabalhador.sobrenome,
            "idade": trabalhador.idade,
            "email": trabalhador.email,
            "senha": trabalhador.senha
        ]
        
        // If object is valid JSON, sends data to server.
        if (JSONSerialization.isValidJSONObject(trabalhadorDict)) {
            print("Sending data to server...")
            let data = try! JSONSerialization.data(withJSONObject: trabalhadorDict)
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.httpBody = data
            let task = URLSession.shared.dataTask(with: urlRequest)
            task.resume()
        } else {
            print("JSON object is invalid!")
        }
    }
    
    static func getTrabalhador() -> [Trabalhador] {
        
        let url = URL(string: "https://jobruralapp.mybluemix.net/listaBanco")!
        
        let (data, _, error) = URLSession.shared.synchronousDataTask(with: url)
        
        if error != nil {
            return []
        }else{
            let json =  try! JSONSerialization.jsonObject(with: data!, options: []) as! [[String: AnyObject]]
            var trabalhadores = [Trabalhador]()
            for obj in json {
                let trabalhador = Trabalhador(json: obj)
                trabalhadores.append(Trabalhador)
            }
            return trabalhadores
        }
        
        
    }
    
    
}
