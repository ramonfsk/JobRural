//
//  Worker.swift
//  TrabalhoRural
//
//  Created by Ramon Ferreira on 02/08/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import Foundation

class Worker {
    var idUser: String?
    var type: String?
    var email: String?
    var name: String?
    var lastName: String?
    var carrer: String?
    var gender: String?
    var age: Int?
    var telephone: Int?
    var nation: String?
    var state: String?
    var city: String?
    var qualifications: String?
    var rankGeneral: Int?
    
    init(json: [String: AnyObject]) {
        self.idUser = json["_id"] as? String ?? ""
        self.type = json["type"] as? String ?? ""
        self.email = json["email"] as? String ?? ""
        self.name = json["name"] as? String ?? ""
        self.lastName = json["lastName"] as? String ?? ""
        self.carrer = json["carrer"] as? String ?? ""
        self.gender = json["gender"] as? String ?? ""
        self.age = json["age"] as? Int ?? 0
        self.telephone = json["telephone"] as? Int ?? 0
        self.nation = json["nation"] as? String ?? ""
        self.state = json["state"] as? String ?? ""
        self.city = json["city"] as? String ?? ""
        self.qualifications = json["qualifications"] as? String ?? ""
        self.rankGeneral = json["rankGeneral"] as? Int ?? 0
    }
    
    init(){}
}

class WorkerDAO {
    static func postWorker(worker: Worker) {
        let url = URL(string: "https://jobrural.mybluemix.net/insert")!
        
        // Convert from Estacionamento to a valid JSON object (eg: Dictionary).
        let workerDict: [String: Any] = [
            "_id": worker.idUser,
            "type": "profileWorker",
            "email": worker.name,
            "name": worker.lastName,
            "carrer": worker.carrer,
            "gender": worker.gender,
            "age": worker.age,
            "telephone": worker.telephone,
            "nation": worker.nation,
            "state": worker.state,
            "city": worker.city,
            "qualifications": worker.qualifications,
            "rankGeneral": worker.rankGeneral
        ]
        
        // If object is valid JSON, sends data to server.
        if (JSONSerialization.isValidJSONObject(workerDict)) {
            print("Sending data to server...")
            let data = try! JSONSerialization.data(withJSONObject: workerDict)
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.httpBody = data
            let task = URLSession.shared.dataTask(with: urlRequest)
            task.resume()
        } else {
            print("JSON object is invalid!")
        }
    }
    
    static func getWorker() -> [Worker] {
        
        let url = URL(string: "https://jobrural.mybluemix.net/getAll")!
        
        let (data, _, error) = URLSession.shared.synchronousDataTask(with: url)
        
        if error != nil {
            return []
        }else{
            let json =  try! JSONSerialization.jsonObject(with: data!, options: []) as! [[String: AnyObject]]
            var workers = [Worker]()
            for obj in json {
                let worker = Worker(json: obj)
                workers.append(worker)
            }
            return workers
        }
    }
}
