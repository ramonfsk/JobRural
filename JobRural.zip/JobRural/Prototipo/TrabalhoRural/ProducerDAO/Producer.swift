//
//  Producer.swift
//  TrabalhoRural
//
//  Created by Ramon Ferreira on 03/08/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import Foundation

class Producer {
    
}
