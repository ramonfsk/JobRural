//
//  TrabalhadoresUITableView.swift
//  JobRural
//
//  Created by student on 02/08/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import UIKit

class TrabalhadoresUITableView: UITableView, UITableViewDelegate{
    
    var jobs = ["cell"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jobs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellRow = tableView.dequeueReusableCell(withIdentifier: "cell")
        cellRow?.textLabel?.text = jobs[indexPath.row]
        
        return cellRow!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    }
    
     func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let detailsJobView = segue.destination as! DetailsJobViewController
        //detailsJobView.job = "teste"
        
        let job = Job(json: ["companyName": "TESTE" as AnyObject, "office": "teste2" as AnyObject])
        
        detailsJobView.job = job
        
    var trab = [Producer]()

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    func numberOfRows(inSection section: Int) -> Int {
        
    
        
        return 1
    }

}
}
