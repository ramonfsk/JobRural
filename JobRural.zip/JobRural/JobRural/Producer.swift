//
//  Producer.swift
//  JobRural
//
//  Created by student on 27/07/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import Foundation

extension URLSession {
    func synchronousDataTask(with url: URL) -> (Data?, URLResponse?, Error?) {
        var data: Data?
        var response: URLResponse?
        var error: Error?
        
        let semaphore = DispatchSemaphore(value: 0)
        
        let dataTask = self.dataTask(with: url) {
            data = $0
            response = $1
            error = $2
            
            semaphore.signal()
        }
        dataTask.resume()
        
        _ = semaphore.wait(timeout: .distantFuture)
        
        return (data, response, error)
    }
}

class Producer {
    var nome: String = ""
    var sobrenome: String = ""
    var idade: String = ""
    var email: String = ""
    var senha: String = ""
    var nomeFazenda: String = ""
    var registroFazenda: String = ""
    var enderecoFazenda: String = ""
    
    
    init(json: [String: AnyObject]) {
        self.nome = json["nome"] as? String ?? ""
        self.sobrenome = json["sobrenome"] as? String ?? ""
        self.idade = json["idade"] as? String ?? ""
        self.email = json["email"] as? String ?? ""
        self.senha = json["senha"] as? String ?? ""
        self.nomeFazenda = json["nome da fazenda"] as? String ?? ""
        self.registroFazenda = json["registro da fazenda"] as? String ?? ""
        self.enderecoFazenda = json["endereço da fazenda"] as? String ?? ""
        
    }
}

class ProducerDAO {
    
    static func postProducer(producer: Producer) {
        let url = URL(string: "https://jobrural.mybluemix.net/insert")!
        
        // Convert from Estacionamento to a valid JSON object (eg: Dictionary).
        let producerDict: [String: Any] = [
            "nome": producer.nome,
            "sobrenome": producer.sobrenome,
            "idade": producer.idade,
            "email": producer.email,
            "senha": producer.senha,
            "nome da fazenda": producer.nomeFazenda,
            "registro da fazenda": producer.registroFazenda,
            "endereco da fazenda": producer.enderecoFazenda
        ]
        
        // If object is valid JSON, sends data to server.
        if (JSONSerialization.isValidJSONObject(producerDict)) {
            print("Sending data to server...")
            let data = try! JSONSerialization.data(withJSONObject: producerDict)
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.httpBody = data
            let task = URLSession.shared.dataTask(with: urlRequest)
            task.resume()
        } else {
            print("JSON object is invalid!")
        }
    }
    
    static func getProducer() -> [Producer] {
        
        let url = URL(string: "https://jobrural.mybluemix.net/getAll")!
        
        let (data, _, error) = URLSession.shared.synchronousDataTask(with: url)
        
        if error != nil {
            return []
        }else{
            let json =  try! JSONSerialization.jsonObject(with: data!, options: []) as! [[String: AnyObject]]
            var producers = [Producer]()
            for obj in json {
                let producer = Producer(json: obj)
                producers.append(producer)
            }
            return producers
        }
    }
}
