//
//  NewRegisterProducerViewController.swift
//  JobRural
//
//  Created by student on 02/08/18.
//  Copyright © 2018 Reis do Gado. All rights reserved.
//

import UIKit

class NewRegisterProducerViewController: UIViewController {

    
    @IBOutlet weak var nameProducer: UITextField!
    
    @IBOutlet weak var lastNameProducer: UITextField!
    
    @IBOutlet weak var ageProducer: UITextField!
    
    @IBOutlet weak var emailProducer: UITextField!
    
    @IBOutlet weak var passProducer: UITextField!
    
    @IBOutlet weak var nameFarm: UITextField!
    
    @IBOutlet weak var register: UITextField!
    
    @IBOutlet weak var adress: UITextField!
    
    @IBAction func buttonConcluir(_ sender: Any) {
        let producer = Producer()
        producer.nome = self.nameProducer.text!
        producer.sobrenome = self.lastNameProducer.text!
        producer.email = self.emailProducer.text!
        producer.idade = self.ageProducer.text!
        producer.senha = self.passProducer.text!
        producer.nomeFazenda = self.nameFarm.text!
        producer.registroFazenda = self.register.text!
        producer.enderecoFazenda = self.adress.text!
        
        ProducerDAO.postProducer(producer: producer)
        print(producer)
        
    }
 
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
